/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body (FSM - FINAL VERSION)
 ******************************************************************************
 * @attention
 * This firmware includes fixes for: Advanced Error Handling (Init Error vs. Runtime Error), 
 * Button Logic, v� Sleep Mode LCD Backlight OFF.
 *
 * LUU �: �?m b?o b?n d� s?a thu vi?n i2c_lcd.c d? h? tr? lcd_backlight_off() 
 * v� d� khai b�o SystemState_t trong energy_meter.h.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "i2c_lcd.h"
#include "ina219.h"
#include "Button.h"
#include "stdio.h"
#include "energy_meter.h" 
#include "stm32f1xx.h" 

#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define RELAY_BATTERY_PIN       GPIO_PIN_14
#define RELAY_USB_PIN           GPIO_PIN_15
#define RELAY_PORT              GPIOC

#define BUTTON_CHARGE_BAT_PIN   GPIO_PIN_6
#define BUTTON_CHARGE_USB_PIN   GPIO_PIN_4
#define BUTTON_SLEEP_PIN        GPIO_PIN_0
#define BUTTON_PORT             GPIOA


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
// Watchdog d� du?c lo?i b?
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef hi2c2;

TIM_HandleTypeDef htim1;

/* USER CODE BEGIN PV */
SystemState_t currentState = FSM_INITIALIZE;

// INA219 structs
INA219_t ina219In;
INA219_t ina219Out;
I2C_LCD_HandleTypeDef lcd;

EMeter_System_t systemHandle; 

uint8_t lcd_is_ok = 0;

// Flag Entry Action
uint8_t clearLcdFlag = 1;
uint8_t batteryModeEntryFlag = 1; 
uint8_t usbModeEntryFlag = 1;     
uint8_t sleepEntryFlag = 1;
uint8_t reportEntryFlag = 1;
uint8_t initEntryFlag = 0; 
uint8_t initDoneFlag = 0; 

uint8_t isUsbButtonPressTimeOut = 0;
uint8_t isBatButtonPressTimeOut = 0;

uint8_t SleepMode_Activated = 0;

// Button structures
Button_Typdef chargeBatteryButton;
Button_Typdef chargeUsbButton;
Button_Typdef sleepButton;

char lcdLine0[21], lcdLine1[21], lcdLine2[21], lcdLine3[21];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_I2C2_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

void displayData(void);
void displayReportData(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void btn_press_short_callback(Button_Typdef *ButtonX)
{
    if (currentState == FSM_SLEEP_MODE) {
        if (ButtonX == &sleepButton) {
            currentState = FSM_INITIALIZE;  
            return;
        }
    }
    
    if (currentState != FSM_SLEEP_MODE) {
        if (ButtonX == &chargeBatteryButton) {
            currentState = FSM_CHARGE_BATTERY;
            batteryModeEntryFlag = 1;
        } else if (ButtonX == &chargeUsbButton) {
            currentState = FSM_CHARGE_USB;
            usbModeEntryFlag = 1;
        }
    }
}

void btn_press_timeout_callback(Button_Typdef *ButtonX)
{
    if (ButtonX == &sleepButton) {
        if (currentState != FSM_SLEEP_MODE) {
            currentState = FSM_SLEEP_MODE;
						SleepMode_Activated = 1;
						return;
        }
    } else {
				if (ButtonX == &chargeBatteryButton) {
						isBatButtonPressTimeOut = 1;
				}
				else if(ButtonX == &chargeUsbButton) {
						isUsbButtonPressTimeOut = 1;
				}
    }
		if(isBatButtonPressTimeOut && isUsbButtonPressTimeOut){
				if(currentState == FSM_REPORT_MODE){
						EMeter_Reset_Report_Data(&systemHandle); 
						lcd_clear(&lcd);
						lcd_gotoxy(&lcd, 0, 1); lcd_puts(&lcd, " ALL DATA RESET!  ");
						HAL_Delay(1500); 
						lcd_clear(&lcd);
						currentState = FSM_INITIALIZE;
						initEntryFlag = 1;
				}
		}
		else if (isBatButtonPressTimeOut == 1 && isUsbButtonPressTimeOut == 0) {
				if(currentState != FSM_REPORT_MODE && currentState != FSM_SLEEP_MODE){
						currentState = FSM_REPORT_MODE;
						reportEntryFlag = 1;
				}
		}
}
		
void btn_release_callback(Button_Typdef *ButtonX){
		if (ButtonX == &chargeBatteryButton) 
				isBatButtonPressTimeOut = 0;
		else if(ButtonX == &chargeUsbButton) 
			isUsbButtonPressTimeOut = 0;
}

void AutoFormatValue(float value, char *buffer, size_t bufferSize, const char *baseUnit)
{
    if (value < 0.0f) {

        if (strcmp(baseUnit, "Wh") == 0) {
            snprintf(buffer, bufferSize, "0.000Wh");
        } else if (strcmp(baseUnit, "mA") == 0) {
            snprintf(buffer, bufferSize, "0.000mA");
        } else {
            snprintf(buffer, bufferSize, "0.00%s", baseUnit); 
        }
        return;
    }
    
    float displayValue = value;
    const char *unit = baseUnit;

    if (strcmp(baseUnit, "Wh") == 0) {
        if (displayValue >= 1000.0f) {
            snprintf(buffer, bufferSize, "%.0f%s", displayValue, unit); // Ví dụ: 1234Wh
        } else if (displayValue >= 100.0f) {
            // 100.0 - 999.9 -> xxx.y (3 trước, 1 sau)
            snprintf(buffer, bufferSize, "%.1f%s", displayValue, unit);
        } else if (displayValue >= 10.0f) {
            // 10.00 - 99.99 -> ab.dc (2 trước, 2 sau)
            snprintf(buffer, bufferSize, "%.2f%s", displayValue, unit);
        } else if (displayValue >= 1.0f) {
            // 1.000 - 9.999 -> a.bcd (1 trước, 3 sau)
            snprintf(buffer, bufferSize, "%.3f%s", displayValue, unit);
        } else {
            // < 1.0 (Yêu cầu: KHÔNG ĐƯA VỀ mWh, hiển thị 0.xxxWh)
            snprintf(buffer, bufferSize, "%.3f%s", displayValue, unit); // Ví dụ: 0.123Wh
        }
        return;
    }

    if (strcmp(baseUnit, "mA") == 0) {
        if (displayValue >= 1000.0f) {
						displayValue /= 1000;
            unit = "A";
					
            if (displayValue >= 100.0f) {
                snprintf(buffer, bufferSize, "%.2f%s", displayValue, unit); 
            } else if (displayValue >= 10.0f) {
                snprintf(buffer, bufferSize, "%.3f%s", displayValue, unit); // 12.345A
            } else {
                snprintf(buffer, bufferSize, "%.4f%s", displayValue, unit); // 1.2345A
            }
            return;
        }
        
        if (displayValue >= 100.0f) {
            snprintf(buffer, bufferSize, "%.1f%s", displayValue, unit); // 999.9mA
        } else if (displayValue >= 10.0f) {
            snprintf(buffer, bufferSize, "%.2f%s", displayValue, unit); // 10.00mA
        } else { 
            // 0.000 - 9.999mA
            snprintf(buffer, bufferSize, "%.3f%s", displayValue, unit); // 1.234mA hoặc 0.123mA
        }
        return;
    }

    if (displayValue >= 100.0f) {
        snprintf(buffer, bufferSize, "%.0f%s", displayValue, unit);
    } else if (displayValue >= 10.0f) {
        snprintf(buffer, bufferSize, "%.1f%s", displayValue, unit);
    } else if (displayValue >= 1.0f) {
        snprintf(buffer, bufferSize, "%.2f%s", displayValue, unit);
    } else {
        // Scale xuống đơn vị milli- (m)
        displayValue *= 1000.0f;
        char milliUnit[5];
        snprintf(milliUnit, sizeof(milliUnit), "m%s", baseUnit);
        unit = milliUnit;

        if (displayValue >= 100.0f)
            snprintf(buffer, bufferSize, "%.0f%s", displayValue, unit);
        else if (displayValue >= 10.0f)
            snprintf(buffer, bufferSize, "%.1f%s", displayValue, unit);
        else if (displayValue >= 1.0f)
            snprintf(buffer, bufferSize, "%.2f%s", displayValue, unit);
        else
            snprintf(buffer, bufferSize, "%.1f%s", displayValue, unit);
    }
}

void displayData(void)
{
    float avgVoltageIn = systemHandle.input.avgVoltage;
    float avgCurrentIn = systemHandle.input.avgCurrent; 
    float avgVoltageOut = systemHandle.output.avgVoltage;
    float avgCurrentOut = systemHandle.output.avgCurrent; 
    float efficiency = systemHandle.efficiency;
    float totalEnergyUsb = systemHandle.reportData.totalEnergyUsb;
		float totalEnergyBattery = systemHandle.reportData.totalEnergyBattery;
	
		float powerOut = avgVoltageOut * (avgCurrentOut / 1000.0f); 
	
		char voltInStr[8];  
    char voltOutStr[8]; 
    char currentInStr[8];  
    char currentOutStr[8]; 
    char powerStr[8];      
    char energyStr[8];     
    
    AutoFormatValue(avgVoltageIn, voltInStr, sizeof(voltInStr), "V");
    AutoFormatValue(avgVoltageOut, voltOutStr, sizeof(voltOutStr), "V");
    AutoFormatValue(avgCurrentIn, currentInStr, sizeof(currentInStr), "mA");
    AutoFormatValue(avgCurrentOut, currentOutStr, sizeof(currentOutStr), "mA");
    AutoFormatValue(powerOut, powerStr, sizeof(powerStr), "W");
    

    const char *modeStr;
    if (currentState == FSM_CHARGE_BATTERY) {
        modeStr = "BAT";
				AutoFormatValue(totalEnergyBattery, energyStr, sizeof(energyStr), "Wh");
    } else if (currentState == FSM_CHARGE_USB) {
        modeStr = "USB";
				AutoFormatValue(totalEnergyUsb, energyStr, sizeof(energyStr), "Wh");
    } else {
        modeStr = "UNK";
    }  

    snprintf(lcdLine0, sizeof(lcdLine0), "MODE:  %s   H:%.1f%%", modeStr, efficiency);
    lcd_gotoxy(&lcd, 0, 0); lcd_puts(&lcd, lcdLine0);

    snprintf(lcdLine1, sizeof(lcdLine1), "IN:  %s - %s", voltInStr, currentInStr);
    lcd_gotoxy(&lcd, 0, 1); lcd_puts(&lcd, lcdLine1);

    snprintf(lcdLine2, sizeof(lcdLine2), "OUT: %s - %s", voltOutStr, currentOutStr);
    lcd_gotoxy(&lcd, 0, 2); lcd_puts(&lcd, lcdLine2);

    snprintf(lcdLine3, sizeof(lcdLine3), "POW: %s - %s", powerStr, energyStr);
    lcd_gotoxy(&lcd, 0, 3); lcd_puts(&lcd, lcdLine3);
}

void displayReportData(void)
{
    float totalEnergyBattery    = systemHandle.reportData.totalEnergyBattery;
    float totalEnergyInBattery  = systemHandle.reportData.totalEnergyInBattery;
    float totalEnergyUsb        = systemHandle.reportData.totalEnergyUsb;
    float totalEnergyInUsb      = systemHandle.reportData.totalEnergyInUsb;

    float avgEffBat = 0.0f;
    if (totalEnergyInBattery > 0.0001f) {
        avgEffBat = (totalEnergyBattery / totalEnergyInBattery) * 100.0f;
    }

    float avgEffUsb = 0.0f;
    if (totalEnergyInUsb > 0.0001f) {
        avgEffUsb = (totalEnergyUsb / totalEnergyInUsb) * 100.0f;
    }

    char batEnergyStr[16];
    char usbEnergyStr[16];

    AutoFormatValue(totalEnergyBattery, batEnergyStr, sizeof(batEnergyStr), "Wh");
    AutoFormatValue(totalEnergyUsb,     usbEnergyStr, sizeof(usbEnergyStr), "Wh");

    snprintf(lcdLine0, sizeof(lcdLine0), "   SYSTEM REPORT    ");
    lcd_gotoxy(&lcd, 0, 0);
    lcd_puts(&lcd, lcdLine0);

    snprintf(lcdLine1, sizeof(lcdLine1), "BAT:%s H:%.1f%%", batEnergyStr, avgEffBat);
    lcd_gotoxy(&lcd, 0, 1);
    lcd_puts(&lcd, lcdLine1);

    snprintf(lcdLine2, sizeof(lcdLine2), "USB:%s H:%.1f%%", usbEnergyStr, avgEffUsb);
    lcd_gotoxy(&lcd, 0, 2);
    lcd_puts(&lcd, lcdLine2);

    snprintf(lcdLine3, sizeof(lcdLine3), "                    ");
    lcd_gotoxy(&lcd, 0, 3);
    lcd_puts(&lcd, lcdLine3);
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_I2C2_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */


	button_init(&sleepButton, BUTTON_PORT, BUTTON_SLEEP_PIN);
	button_init(&chargeBatteryButton, BUTTON_PORT, BUTTON_CHARGE_BAT_PIN);
	button_init(&chargeUsbButton, BUTTON_PORT, BUTTON_CHARGE_USB_PIN);

	lcd.hi2c = &hi2c1;
	lcd.address = (0x27 << 1);
	INA219_Init(&ina219In, &hi2c2, 0x40);
	INA219_Init(&ina219Out, &hi2c2, 0x41);
    
  EMeter_System_Init(&systemHandle, &ina219In, &ina219Out);
    
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    button_handle(&sleepButton);
    button_handle(&chargeBatteryButton);
    button_handle(&chargeUsbButton);
     
    switch (currentState)
    {
        case FSM_INITIALIZE:
            if (initDoneFlag == 0) {
                lcd_init(&lcd);
                if (HAL_I2C_IsDeviceReady(&hi2c1, (0x27 << 1), 3, 100) == HAL_OK) {
                    lcd_is_ok = 1;
                    if (lcd_is_ok) lcd_backlight_on(&lcd); 
                    lcd_clear(&lcd);
										lcd_gotoxy(&lcd, 0, 0);
                    lcd_puts(&lcd, "...System Start...");
                    HAL_Delay(1000);
										
                } else {
                    lcd_is_ok = 0;
                }
								if (!ina219In.is_ready || !ina219Out.is_ready) {
										currentState = FSM_SYSTEM_ERROR;
								} else {
										lcd_gotoxy(&lcd, 0, 1); lcd_puts(&lcd,"INA Ready         ");
										HAL_Delay(1500);
										lcd_clear(&lcd);
								}
                initDoneFlag = 1;
            }
   
						lcd_gotoxy(&lcd, 0, 0); lcd_puts(&lcd,"Please Select Mode ");
						
            batteryModeEntryFlag = 1; 
            usbModeEntryFlag = 1;     
            sleepEntryFlag = 1;
            reportEntryFlag = 1;
						
            break;

        case FSM_CHARGE_BATTERY:
            if (batteryModeEntryFlag) {
                HAL_GPIO_WritePin(RELAY_PORT, RELAY_USB_PIN, GPIO_PIN_RESET);
                HAL_Delay(500); 
                HAL_GPIO_WritePin(RELAY_PORT, RELAY_BATTERY_PIN, GPIO_PIN_SET);
                
                if (lcd_is_ok) { lcd_clear(&lcd); }
                batteryModeEntryFlag = 0; 
            }
            if (!ina219In.is_ready || !ina219Out.is_ready) {
                currentState = FSM_SYSTEM_ERROR;
                clearLcdFlag = 1; 
                break;
            }
            if (lcd_is_ok) { displayData(); }
						EMeter_System_Handle(&systemHandle, currentState);
						HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, systemHandle.ledState);
            break;

        case FSM_CHARGE_USB:
            if (usbModeEntryFlag) {
                HAL_GPIO_WritePin(RELAY_PORT, RELAY_BATTERY_PIN, GPIO_PIN_RESET);
                HAL_Delay(500); 
                HAL_GPIO_WritePin(RELAY_PORT, RELAY_USB_PIN, GPIO_PIN_SET);
                
                if (lcd_is_ok) { lcd_clear(&lcd); }
                usbModeEntryFlag = 0;
                batteryModeEntryFlag = 1;
            }
            if (!ina219In.is_ready || !ina219Out.is_ready) {
                currentState = FSM_SYSTEM_ERROR;
                clearLcdFlag = 1;
                break;
            }
            if (lcd_is_ok) { displayData(); }
						EMeter_System_Handle(&systemHandle, currentState);
						HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, systemHandle.ledState);
            break;

        case FSM_REPORT_MODE:
            if (reportEntryFlag) {
                HAL_GPIO_WritePin(RELAY_PORT, RELAY_BATTERY_PIN | RELAY_USB_PIN, GPIO_PIN_RESET);
                HAL_Delay(100); 
                if (lcd_is_ok) { lcd_clear(&lcd); }
                reportEntryFlag = 0;
            }
            if (lcd_is_ok) { displayReportData(); }
            break;

        case FSM_SLEEP_MODE:
            if (sleepEntryFlag) {						
                HAL_GPIO_WritePin(RELAY_PORT, RELAY_BATTERY_PIN | RELAY_USB_PIN, GPIO_PIN_RESET);
                HAL_Delay(100);															
							
                if (lcd_is_ok) {
                    lcd_clear(&lcd);
                    lcd_gotoxy(&lcd, 0, 0); lcd_puts(&lcd, "----SLEEP MODE----");
                }      
                HAL_Delay(1500);
                if (lcd_is_ok) {
										lcd_clear(&lcd);
                    lcd_backlight_off(&lcd); 
                }
								sleepEntryFlag = 0;
								SleepMode_Activated = 1;
                HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);
            }
            break;

        case FSM_SYSTEM_ERROR:
            if (clearLcdFlag) { 
                HAL_GPIO_WritePin(RELAY_PORT, RELAY_BATTERY_PIN | RELAY_USB_PIN, GPIO_PIN_RESET);
                
                if (lcd_is_ok) {
                    lcd_clear(&lcd); 
                    lcd_gotoxy(&lcd, 0, 0); lcd_puts(&lcd, "SYSTEM ERROR!");
                }
                clearLcdFlag = 0; 
            }
            break;
    }
  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.ClockSpeed = 100000;
  hi2c2.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 63999;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 49;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC14 PC15 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PA4 PA6 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if(GPIO_Pin == GPIO_PIN_0) // Sleep control button
    {
        if(SleepMode_Activated == 1) {
            SleepMode_Activated = 0;
						currentState = FSM_INITIALIZE;
        } else {
            sleepEntryFlag = 1;     // Enter sleep on next loop
        }
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
