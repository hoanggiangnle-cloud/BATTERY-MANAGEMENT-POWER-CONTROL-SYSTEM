#include "main.h"
#include "energy_meter.h"
#include "ina219.h"
#include "stdio.h"
#include "math.h"

static uint8_t isSampling = 0;
static uint8_t isCycleDone = 0;
static uint32_t start_time = 0;

static void EMeter_Measure_Init(MeasurementHandle_t *m, INA219_t *ina) {
    m->ina = ina; 
    m->accVoltage = m->accCurrent = m->accPower = 0.0f;
    m->avgVoltage = m->avgCurrent = m->avgPower = 0.0f;
    m->energyTotal = 0.0f;
}

static uint8_t IsReadDue(EMeter_System_t *system) {
    if (HAL_GetTick() - system->read_due_tick >= EMETER_SAMPLE_PERIOD_MS) {
        system->read_due_tick = HAL_GetTick();
        return 1;
    }
    return 0;
}

static void Calculate_Average_And_Energy(MeasurementHandle_t *m, uint16_t sampleCount, float time_increment_h) {
    
    if (sampleCount == 0) return;

    m->avgVoltage = m->accVoltage / (float)sampleCount;
    m->avgCurrent = m->accCurrent / (float)sampleCount;
    m->avgPower = m->accPower / (float)sampleCount;
    
    if (m->avgCurrent > EMETER_MIN_CURRENT_FOR_ENERGY_MA) { 
        m->energyTotal += (m->avgPower * time_increment_h);
    }

    m->accVoltage = m->accCurrent = m->accPower = 0.0f;
}


void EMeter_Measure_Handle(MeasurementHandle_t *m) {
    
    float current_mA = INA219_ReadCurrent(m->ina); 
    float voltage_V = INA219_ReadBusVoltage(m->ina);
    float power_W = INA219_ReadPower(m->ina) / 1000.0f; // Chuyển mW sang W

    m->accVoltage += voltage_V;
    m->accCurrent += current_mA;
    m->accPower += power_W;
}


void EMeter_System_Init(EMeter_System_t *system, INA219_t *inaIn, INA219_t *inaOut) {
    EMeter_Measure_Init(&(system->input), inaIn);
    EMeter_Measure_Init(&(system->output), inaOut);
    
    system->efficiency = 0.0f;
    system->sampleCount = 0;
    system->read_due_tick = HAL_GetTick();

    EMeter_Reset_Report_Data(system);
}

void EMeter_Reset_Report_Data(EMeter_System_t *system) {
    system->reportData.totalEnergyBattery    = 0.0f;
    system->reportData.totalEnergyInBattery  = 0.0f;
    system->reportData.totalEnergyUsb        = 0.0f;
    system->reportData.totalEnergyInUsb      = 0.0f;

    system->input.accVoltage = 0.0f;
    system->input.accCurrent = 0.0f;
    system->input.accPower   = 0.0f;
    system->input.avgVoltage = 0.0f;
    system->input.avgCurrent = 0.0f;
    system->input.avgPower   = 0.0f;
    system->input.energyTotal = 0.0f;

    system->output.accVoltage = 0.0f;
    system->output.accCurrent = 0.0f;
    system->output.accPower   = 0.0f;
    system->output.avgVoltage = 0.0f;
    system->output.avgCurrent = 0.0f;
    system->output.avgPower   = 0.0f;
    system->output.energyTotal = 0.0f;

    system->efficiency = 0.0f;
    system->sampleCount = 0;

    system->read_due_tick = HAL_GetTick();
}


void EMeter_System_Handle(EMeter_System_t *system, SystemState_t currentState)
{
    if (!IsReadDue(system)) {
			if(isCycleDone){
				if(HAL_GetTick() - start_time > LED_CYCLE_END_PULSE_MS){
					system->ledState = 1;
					isCycleDone = 0;
					isSampling = 0;
				}
			}
			else if(isSampling){
				if(HAL_GetTick() - start_time > LED_SAMPLE_PULSE_MS){
					system->ledState = 1;
					isSampling = 0;
				}
			}
        return;
    }
		
		start_time = HAL_GetTick();
		isSampling = 1;
		system->ledState = 0;
		
    system->sampleCount++; 
    EMeter_Measure_Handle(&(system->input));
    EMeter_Measure_Handle(&(system->output));
    if (system->sampleCount >= EMETER_SAMPLE_COUNT_MAX) {
			
				start_time = HAL_GetTick();
				isCycleDone = 1;
				system->ledState = 0;
        
        float time_increment_h = (float)EMETER_AVERAGING_PERIOD_MS / 3600000.0f;

        Calculate_Average_And_Energy(&(system->input), EMETER_SAMPLE_COUNT_MAX, time_increment_h);
        Calculate_Average_And_Energy(&(system->output), EMETER_SAMPLE_COUNT_MAX, time_increment_h);
        
        if (system->input.avgPower > EMETER_MIN_POWER_FOR_EFFICIENCY_W) {
            system->efficiency = system->output.avgPower * 100.0f / system->input.avgPower;
            if (system->efficiency > 100.0f) {
                system->efficiency = 100.0f;
            }
        } else {
            system->efficiency = 0.0f;
        }
        float avgP_in = system->input.avgPower;
        float avgP_out = system->output.avgPower;
        float avgI_out = system->output.avgCurrent;

        if (currentState == FSM_CHARGE_BATTERY) {
            if (avgP_in > EMETER_MIN_POWER_FOR_EFFICIENCY_W) {
                system->reportData.totalEnergyInBattery += (avgP_in * time_increment_h);
            }
            if (avgI_out > EMETER_MIN_CURRENT_FOR_ENERGY_MA) {
                system->reportData.totalEnergyBattery += (avgP_out * time_increment_h);
            }
        } else if (currentState == FSM_CHARGE_USB) {
            if (avgP_in > EMETER_MIN_POWER_FOR_EFFICIENCY_W) {
                system->reportData.totalEnergyInUsb += (avgP_in * time_increment_h);
            }
            if (avgI_out > EMETER_MIN_CURRENT_FOR_ENERGY_MA) {
                system->reportData.totalEnergyUsb += (avgP_out * time_increment_h);
            }
        }
        system->sampleCount = 0;
    }
}
