#include "INA219.h"

// Default I2C address (can be changed when initializing)
#define INA219_DEFAULT_ADDRESS  (0x40 << 1)  // 7-bit address shifted for HAL

// ========== WRITE 16-BIT TO REGISTER ==========
static void INA219_WriteRegister(INA219_t *ina219, uint8_t reg, uint16_t value)
{
    uint8_t data[3];
    data[0] = reg;
    data[1] = (uint8_t)((value >> 8) & 0xFF);
    data[2] = (uint8_t)(value & 0xFF);
    HAL_I2C_Master_Transmit(ina219->hi2c, ina219->Address, data, 3, HAL_MAX_DELAY);
}

// ========== READ 16-BIT FROM REGISTER ==========
static uint16_t INA219_ReadRegister(INA219_t *ina219, uint8_t reg)
{
    uint8_t data[2];
    HAL_I2C_Master_Transmit(ina219->hi2c, ina219->Address, &reg, 1, HAL_MAX_DELAY);
    HAL_I2C_Master_Receive(ina219->hi2c, ina219->Address, data, 2, HAL_MAX_DELAY);
    return ((uint16_t)data[0] << 8) | data[1];
}

// ========== INITIALIZATION ==========
void INA219_Init(INA219_t *ina219, I2C_HandleTypeDef *hi2c, uint8_t address)
{
    uint16_t read_config = 0;
    
    ina219->hi2c = hi2c;
    ina219->Address = (address << 1);
    
    INA219_setCalibration_32V_2A(ina219); 
    
    read_config = INA219_ReadRegister(ina219, INA219_REG_CONFIG);
    
    uint16_t expected_config = INA219_CONFIG_BVOLTAGERANGE_32V |
                               INA219_CONFIG_GAIN_8_320MV |
                               INA219_CONFIG_BADCRES_12BIT |
                               INA219_CONFIG_SADCRES_12BIT |
                               INA219_CONFIG_MODE_SANDBVOLT_CONTINUOUS;
    
    if (read_config == expected_config)
    {
        ina219->is_ready = 1; 
    }
    else
    {
        ina219->is_ready = 0;
    }
}
// ========== CALIBRATION: 32V, 2A ==========
void INA219_setCalibration_32V_2A(INA219_t *ina219)
{
    ina219->calibrationValue = 4096;        // Default calibration
    ina219->currentDivider_mA = 10.0f;      // 1 LSB = 0.1 mA
    ina219->powerMultiplier_mW = 2.0f;      // 1 LSB = 2 mW

    INA219_WriteRegister(ina219, INA219_REG_CALIBRATION, ina219->calibrationValue);

    uint16_t config = INA219_CONFIG_BVOLTAGERANGE_32V |
                      INA219_CONFIG_GAIN_8_320MV |
                      INA219_CONFIG_BADCRES_12BIT |
                      INA219_CONFIG_SADCRES_12BIT |
                      INA219_CONFIG_MODE_SANDBVOLT_CONTINUOUS;

    INA219_WriteRegister(ina219, INA219_REG_CONFIG, config);
}

// ========== CALIBRATION: 32V, 1A ==========
void INA219_setCalibration_32V_1A(INA219_t *ina219)
{
    ina219->calibrationValue = 10240;
    ina219->currentDivider_mA = 25.0f;  // 1 LSB = 0.04 mA
    ina219->powerMultiplier_mW = 0.8f;

    INA219_WriteRegister(ina219, INA219_REG_CALIBRATION, ina219->calibrationValue);

    uint16_t config = INA219_CONFIG_BVOLTAGERANGE_32V |
                      INA219_CONFIG_GAIN_8_320MV |
                      INA219_CONFIG_BADCRES_12BIT |
                      INA219_CONFIG_SADCRES_12BIT |
                      INA219_CONFIG_MODE_SANDBVOLT_CONTINUOUS;

    INA219_WriteRegister(ina219, INA219_REG_CONFIG, config);
}

// ========== CALIBRATION: 16V, 400mA ==========
void INA219_setCalibration_16V_400mA(INA219_t *ina219)
{
    ina219->calibrationValue = 8192;
    ina219->currentDivider_mA = 20.0f;
    ina219->powerMultiplier_mW = 1.0f;

    INA219_WriteRegister(ina219, INA219_REG_CALIBRATION, ina219->calibrationValue);

    uint16_t config = INA219_CONFIG_BVOLTAGERANGE_16V |
                      INA219_CONFIG_GAIN_1_40MV |
                      INA219_CONFIG_BADCRES_12BIT |
                      INA219_CONFIG_SADCRES_12BIT |
                      INA219_CONFIG_MODE_SANDBVOLT_CONTINUOUS;

    INA219_WriteRegister(ina219, INA219_REG_CONFIG, config);
}

// ========== SET POWER MODE ==========
void INA219_setPowerMode(INA219_t *ina219, uint8_t mode)
{
    uint16_t config = INA219_ReadRegister(ina219, INA219_REG_CONFIG);
    config &= ~INA219_CONFIG_MODE_MASK;  // Clear mode bits
    config |= (mode & INA219_CONFIG_MODE_MASK);
    INA219_WriteRegister(ina219, INA219_REG_CONFIG, config);
}

// ========== READ VOLTAGES AND CURRENT ==========
float INA219_ReadShuntVoltage(INA219_t *ina219)
{
    int16_t value = (int16_t)INA219_ReadRegister(ina219, INA219_REG_SHUNTVOLTAGE);
    return value * 0.01f;   // 10�V per LSB ? 0.01mV
}

float INA219_ReadBusVoltage(INA219_t *ina219)
{
    uint16_t value = INA219_ReadRegister(ina219, INA219_REG_BUSVOLTAGE);
    return ((value >> 3) * 4.0f) / 1000.0f; // 4mV per bit ? volts
}

float INA219_ReadCurrent(INA219_t *ina219)
{
    INA219_WriteRegister(ina219, INA219_REG_CALIBRATION, ina219->calibrationValue);
    int16_t value = (int16_t)INA219_ReadRegister(ina219, INA219_REG_CURRENT);
    return ((float)value) / ina219->currentDivider_mA;
}

float INA219_ReadPower(INA219_t *ina219)
{
    int16_t value = (int16_t)INA219_ReadRegister(ina219, INA219_REG_POWER);
    return ((float)value) * ina219->powerMultiplier_mW;
}

// ========== BATTERY STATUS CHECK ==========
BatteryState INA219_CheckBattery(float voltage)
{
    if (voltage > 12.0f)
        return Battery_OK;
    else if (voltage > 10.5f)
        return Battery_LOW;
    else
        return Battery_START;
}
