#ifndef __ENERGY_METER_H
#define __ENERGY_METER_H

#include "main.h"      
#include "ina219.h"  

// --- HẰNG SỐ ĐO LƯỜNG ---
#define EMETER_SAMPLE_PERIOD_MS             600 
#define EMETER_AVERAGING_PERIOD_MS          3000   
#define EMETER_SAMPLE_COUNT_MAX             (EMETER_AVERAGING_PERIOD_MS / EMETER_SAMPLE_PERIOD_MS) 

#define EMETER_MIN_CURRENT_FOR_ENERGY_MA    100.0f  
#define EMETER_MIN_POWER_FOR_EFFICIENCY_W   0.001f   

#define LED_SAMPLE_PULSE_MS                 1
#define LED_CYCLE_END_PULSE_MS              200

typedef enum {
    FSM_INITIALIZE = 0,     
    FSM_SENSOR_CHECK,       
    FSM_CHARGE_BATTERY,     
    FSM_CHARGE_USB,         
    FSM_REPORT_MODE,        
    FSM_SYSTEM_ERROR,       
    FSM_SLEEP_MODE          
} SystemState_t;  

typedef struct {
    // --- Dữ liệu Tích lũy (Accumulation) ---
    float accVoltage;
    float accCurrent;
    float accPower;

    // --- Dữ liệu Trung bình (Average) ---
    float avgVoltage;
    float avgCurrent;
    float avgPower;

    // --- Dữ liệu Năng lượng (Energy) ---
    float energyTotal; // Tích lũy năng lượng tổng (Wh)

    // BỔ SUNG THÀNH VIÊN THIẾT YẾU ĐỂ KHẮC PHỤC LỖI NÀY
    INA219_t *ina; // Con trỏ tới cấu trúc INA219

} MeasurementHandle_t;


// --- KIỂU DỮ LIỆU BÁO CÁO (REPORT) ---

typedef struct {
    float totalEnergyBattery;    // E_out cho Mode 1 (Charge Battery)
    float totalEnergyInBattery;  // E_in cho Mode 1 (Charge Battery)
    float totalEnergyUsb;        // E_out cho Mode 2 (Charge USB)
    float totalEnergyInUsb;      // E_in cho Mode 2 (Charge USB)
} ReportData_t;


// --- CẤU TRÚC SYSTEM HANDLE CHÍNH ---

typedef struct {
    // Hai đối tượng đo lường
    MeasurementHandle_t input;
    MeasurementHandle_t output;

    // Biến trạng thái
    uint16_t sampleCount;         // Bộ đếm mẫu dùng chung cho cả Input và Output
    uint32_t read_due_tick;       // Tick cuối cùng đọc dùng chung

    // Kết quả tổng hợp hệ thống
    float efficiency;             // Hiệu suất tức thời (%)
    ReportData_t reportData;      // Dữ liệu Báo cáo
		uint8_t ledState;

} EMeter_System_t;


// --- HÀM API ---


/**
 * @brief Khởi tạo Hệ thống Energy Meter (gọi Measure_Init cho In/Out).
 */
void EMeter_System_Init(EMeter_System_t *system, INA219_t *ina_in, INA219_t *ina_out);

/**
 * @brief Hàm xử lý đọc, tích lũy V-I-P cho một kênh.
 */
void EMeter_Measure_Handle(MeasurementHandle_t *measure);

/**
 * @brief Hàm chính xử lý toàn bộ hệ thống (gọi Measure_Handle cho cả hai).
 */
void EMeter_System_Handle(EMeter_System_t *system, uint8_t currentState);

/**
 * @brief Reset toàn bộ dữ liệu báo cáo (Energy Totals) về 0.
 */
void EMeter_Reset_Report_Data(EMeter_System_t *system);


#endif // __ENERGY_METER_H