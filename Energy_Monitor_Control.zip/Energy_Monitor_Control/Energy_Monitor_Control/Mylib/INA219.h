#ifndef __INA219_H__
#define __INA219_H__

#include "stm32f1xx_hal.h"  
#include <stdbool.h>
#include <stdint.h>

// ================== REGISTER ADDRESSES ==================
#define INA219_REG_CONFIG               0x00
#define INA219_REG_SHUNTVOLTAGE         0x01
#define INA219_REG_BUSVOLTAGE           0x02
#define INA219_REG_POWER                0x03
#define INA219_REG_CURRENT              0x04
#define INA219_REG_CALIBRATION          0x05

// ================== CONFIGURATION BITS ==================
#define INA219_CONFIG_MODE_MASK                 (0x0007)

// Operating modes
#define INA219_CONFIG_MODE_POWERDOWN            (0x0000)
#define INA219_CONFIG_MODE_SHUNT_TRIG           (0x0001)
#define INA219_CONFIG_MODE_BUS_TRIG             (0x0002)
#define INA219_CONFIG_MODE_SANDBVOLT_TRIGGERED  (0x0003)
#define INA219_CONFIG_MODE_ADCOFF               (0x0004)
#define INA219_CONFIG_MODE_SANDBVOLT_CONTINUOUS (0x0007)

// Bus voltage range
#define INA219_CONFIG_BVOLTAGERANGE_16V         (0x0000)
#define INA219_CONFIG_BVOLTAGERANGE_32V         (0x2000)

// Gain (shunt voltage range)
#define INA219_CONFIG_GAIN_1_40MV               (0x0000)
#define INA219_CONFIG_GAIN_2_80MV               (0x0800)
#define INA219_CONFIG_GAIN_4_160MV              (0x1000)
#define INA219_CONFIG_GAIN_8_320MV              (0x1800)

// ADC resolution
#define INA219_CONFIG_BADCRES_12BIT             (0x0180)
#define INA219_CONFIG_SADCRES_12BIT             (0x0018)

// ================== BATTERY STATE ENUM ==================
typedef enum {
    Battery_START = 0,
    Battery_OK,
    Battery_LOW
} BatteryState;

// ================== INA219 DEVICE STRUCTURE ==================
typedef struct {
    I2C_HandleTypeDef *hi2c;      // I2C interface handle
    uint8_t Address;              // INA219 device address (default 0x40)
    float currentDivider_mA;      // Current conversion factor (LSB ? mA)
    float powerMultiplier_mW;     // Power conversion factor (LSB ? mW)
    uint16_t calibrationValue;    // Calibration register value
		uint8_t is_ready;
} INA219_t;

// ================== FUNCTION PROTOTYPES ==================

// --- Initialization and configuration ---
void INA219_Init(INA219_t *ina219, I2C_HandleTypeDef *hi2c, uint8_t address);
void INA219_setCalibration_32V_2A(INA219_t *ina219);
void INA219_setCalibration_32V_1A(INA219_t *ina219);
void INA219_setCalibration_16V_400mA(INA219_t *ina219);
void INA219_setPowerMode(INA219_t *ina219, uint8_t mode);

// --- Reading measurements ---
float INA219_ReadBusVoltage(INA219_t *ina219);     // Return voltage on bus (V)
float INA219_ReadShuntVoltage(INA219_t *ina219);   // Return shunt voltage (mV)
float INA219_ReadCurrent(INA219_t *ina219);        // Return current (mA)
float INA219_ReadPower(INA219_t *ina219);          // Return power (mW)

// --- Battery/energy status ---
BatteryState INA219_CheckBattery(float voltage);   // Evaluate battery level

#endif /* __INA219_H__ */
